#!/bin/bash

python run_flow.py \
	-name FILEPATH/4frac_example \
	-input FILEPATH/4_user_defined_ellipses.txt
