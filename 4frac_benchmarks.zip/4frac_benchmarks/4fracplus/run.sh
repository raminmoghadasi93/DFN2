#!/bin/bash

python run_flow.py \
       -name FILEPATH/4fracplus_example \
       -input FILEPATH/4_user_defined_ellipses.txt
